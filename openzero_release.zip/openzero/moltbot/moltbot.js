const express = require('express');
const puppeteer = require('puppeteer');
const app = express();
app.use(express.json());

let browser;
let page;

async function launchBrowser() {
    console.log(">>> LAUNCHING VISIBLE BROWSER...");
    browser = await puppeteer.launch({
        headless: false, // <--- YOU WILL SEE THE WINDOW
        defaultViewport: null,
        args: [
            '--no-sandbox',
            '--disable-setuid-sandbox',
            '--start-maximized',
            '--disable-infobars'
        ]
    });
    page = await browser.newPage();
    console.log(">>> BROWSER IS OPEN AND READY.");
}

// Launch immediately on start so you know it's working
launchBrowser();

app.post('/goto', async (req, res) => {
    const { url } = req.body;
    try {
        console.log("NAVIGATING TO:", url);
        
        // If browser crashed, restart it
        if (!browser || !browser.isConnected()) await launchBrowser();

        await page.goto(url, { waitUntil: 'domcontentloaded', timeout: 15000 });
        
        // Take Screenshot for Dashboard
        await page.screenshot({ path: '../static/vision.png' });
        
        // Get Text
        const text = await page.evaluate(() => document.body.innerText || "NO TEXT");
        const cleanText = text.replace(/\s+/g, ' ').substring(0, 5000);
        
        res.json({ status: "success", content: cleanText });
    } catch (e) {
        console.error("ERROR:", e.message);
        res.json({ status: "error", content: e.message });
    }
});

app.listen(3000, () => console.log(">>> MOLTBOT LISTENING ON PORT 3000"));
