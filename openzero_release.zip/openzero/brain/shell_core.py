import subprocess
import os

class GhostShell:
    def __init__(self):
        # Start in the home directory
        self.current_dir = os.path.expanduser("~")
    
    def execute(self, cmd):
        """
        Executes a command in the current directory and updates the directory
        if the command was a 'cd'.
        """
        try:
            # Chained command to execute in context and return new path
            # We append 'pwd' to capture directory changes
            wrapped_cmd = f"cd '{self.current_dir}' && {cmd} && pwd"
            
            # Run the command
            process = subprocess.Popen(
                wrapped_cmd, 
                shell=True, 
                stdout=subprocess.PIPE, 
                stderr=subprocess.PIPE,
                text=True
            )
            stdout, stderr = process.communicate(timeout=30)
            
            if stderr:
                return f"ERROR:\n{stderr}"
            
            # Parse output
            lines = stdout.strip().split('\n')
            if lines:
                # The last line is the result of 'pwd'
                new_dir = lines[-1]
                if os.path.isdir(new_dir):
                    self.current_dir = new_dir
                    # Return output without the trailing pwd line
                    return '\n'.join(lines[:-1])
            
            return stdout
            
        except Exception as e:
            return f"SHELL CRASH: {str(e)}"

# Singleton Instance
shell = GhostShell()
