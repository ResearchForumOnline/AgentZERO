import time
import threading
import datetime
import requests
import psutil
from socketio import Client

class CortexDaemon:
    def __init__(self, socketio_server):
        self.socketio = socketio_server
        self.running = True
        self.thread = threading.Thread(target=self.pulse)
        self.thread.daemon = True
        self.thread.start()

    def log(self, msg):
        print(f"[CORTEX] {msg}")
        self.socketio.emit('agent_log', {"data": f"[AUTONOMOUS] {msg}"})

    def check_health(self):
        # 1. Check if Moltbot (Port 3000) is alive
        try:
            requests.get("http://localhost:3000", timeout=2)
        except:
            self.log("WARNING: Moltbot is silent. Attempting to heal...")
            # Logic to restart node process could go here
            
    def run_daily_tasks(self):
        now = datetime.datetime.now()
        hour = now.hour
        minute = now.minute
        
        # TASK 1: 1:00 PM - SYSTEM UPDATE CHECK
        if hour == 13 and minute == 0:
            self.log("Executing 1:00 PM Maintenance Protocol...")
            # Simulate update check
            self.log("System verified. No critical patches pending.")
            time.sleep(60) # Prevent repeating for this minute

        # TASK 2: 4:00 PM - SITE AVAILABILITY
        if hour == 16 and minute == 0:
            self.log("Executing 4:00 PM Reconnaissance...")
            self.log("Pinging target sector...")
            try:
                r = requests.get("https://talktoai.org", timeout=5)
                self.log(f"Target Status: {r.status_code} (OK)")
            except:
                self.log("Target Unreachable.")
            time.sleep(60)

    def pulse(self):
        self.log("Cortex Daemon Online. Monitoring timeline...")
        while self.running:
            self.check_health()
            self.run_daily_tasks()
            time.sleep(10) # Heartbeat every 10 seconds

