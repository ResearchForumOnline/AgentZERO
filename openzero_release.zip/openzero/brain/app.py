import os
import requests
import psutil
from flask import Flask, render_template, request, jsonify
from flask_socketio import SocketIO, emit
from rag_engine import ZeroMemory

# IMPORT NEW SOVEREIGN MODULES
from shell_core import shell
from docker_forge import create_docker_infrastructure, build_container
from cortex import CortexDaemon

# SETUP
BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
app = Flask(__name__, 
            static_folder=os.path.join(BASE_DIR, 'static'), 
            template_folder=os.path.join(BASE_DIR, 'templates'))
socketio = SocketIO(app, cors_allowed_origins="*")
memory = ZeroMemory()

# START AUTONOMOUS CORTEX
cortex = CortexDaemon(socketio)

# GLOBAL MEMORY
current_site_text = ""
SYSTEM_PROMPT = """
You are OpenZero.
Identity: Autonomous Sovereign Node.
Capabilities:
1. GHOST SHELL: Persistent terminal. You remember directories.
2. MOLTBOT: Visual browser.
3. FORGE: You can build Docker containers of yourself.
4. CORTEX: You run background tasks automatically.
"""

@app.route('/')
def index(): return render_template('index.html')

@app.route('/stats')
def stats(): return jsonify({"cpu": psutil.cpu_percent(), "ram": psutil.virtual_memory().percent})

@socketio.on('user_message')
def handle_message(data):
    global current_site_text
    msg = data.get('message', '')

    # --- 1. PERSISTENT SHELL COMMANDS ---
    if msg.lower().startswith("run "):
        cmd = msg[4:].strip()
        socketio.emit('agent_log', {"data": f"SHELL EXEC: {cmd}"})
        # Use the GhostShell class instead of subprocess
        output = shell.execute(cmd)
        emit('agent_reply', {"data": f"[{shell.current_dir}]$ {cmd}\n{output}"})
        return

    # --- 2. DOCKER / FORGE COMMANDS ---
    if "create docker" in msg.lower() or "build container" in msg.lower():
        socketio.emit('agent_log', {"data": "INITIATING FORGE PROTOCOL..."})
        res1 = create_docker_infrastructure()
        emit('agent_reply', {"data": f"Blueprint Created: {res1}\n\nTo build, type: 'run docker build -t openzero .'"})
        return

    # --- 3. VISION COMMANDS ---
    if "go to" in msg.lower():
        # (Existing Vision Code Logic - Kept Concise for this update)
        try:
            raw_cmd = msg.lower().split("go to ")[1].strip()
            url = raw_cmd.split(" ")[0]
            if not url.startswith("http"): url = "https://" + url
            socketio.emit('agent_log', {"data": f"NAVIGATING: {url}"})
            res = requests.post("http://localhost:3000/goto", json={"url": url}, timeout=60).json()
            
            if res.get("status") == "success":
                socketio.emit('refresh_vision')
                current_site_text = res.get("content", "")
                
                instr = raw_cmd.replace(url.replace("https://","").replace("http://",""), "").strip()
                if not instr: instr = "Summarize this."
                
                socketio.emit('agent_log', {"data": "ANALYZING..."})
                prompt = f"WEBSITE: {current_site_text[:4000]}\nUSER: {instr}"
                ai = requests.post("http://localhost:11434/api/generate", json={
                    "model": "gemma2:9b", "prompt": prompt, "stream": False
                }, timeout=120)
                emit('agent_reply', {"data": ai.json()['response']})
            else:
                emit('agent_reply', {"data": f"VISION ERROR: {res.get('content')}"})
        except Exception as e:
            emit('agent_reply', {"data": f"ERROR: {e}"})
        return

    # --- 4. CHAT ---
    socketio.emit('agent_log', {"data": "THINKING..."})
    final_prompt = f"{SYSTEM_PROMPT}\nCONTEXT: {current_site_text[:2000]}\nUSER: {msg}\nZERO:"
    try:
        res = requests.post("http://localhost:11434/api/generate", json={
            "model": "gemma2:9b", "prompt": final_prompt, "stream": False
        }, timeout=60)
        emit('agent_reply', {"data": res.json()['response']})
    except:
        emit('agent_reply', {"data": "BRAIN OFFLINE."})

if __name__ == '__main__':
    print(">>> OPENZERO SOVEREIGN NODE ACTIVE <<<")
    socketio.run(app, host='0.0.0.0', port=1024)
